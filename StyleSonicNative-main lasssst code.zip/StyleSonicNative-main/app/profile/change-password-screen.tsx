import React from "react";
import ChangePassword from "../../components/changepassword";

const ChangePasswordScreen: React.FC = () => {
  return <ChangePassword />;
};

export default ChangePasswordScreen;
